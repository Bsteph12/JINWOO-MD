const {
  default: makeWASocket,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  DisconnectReason,
  makeCacheableSignalKeyStore
} = require('@whiskeysockets/baileys');

const readline = require('readline');
const pino = require('pino');
const fs = require('fs');
const path = require('path');

const config = require('./config');
const { stylise, sendMenu, sendReply, db, saveDB } = require('./lib/helpers');

function ask(questionText) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise(resolve => rl.question(questionText, answer => {
    rl.close();
    resolve(answer.trim());
  }));
}

// Fonction pour télécharger le fichier creds.json depuis Mega
async function downloadCredsFromMega(sessionId) {
  const { File } = require('megajs');
  
  try {
    // Créer l'URL Mega complète
    const megaUrl = sessionId.startsWith('http') ? sessionId : `https://mega.nz/file/${sessionId}`;
    
    // Utiliser megajs pour télécharger le fichier
    const file = File.fromURL(megaUrl);
    const data = await file.downloadBuffer();
    
    // Convertir le buffer en string et parser le JSON
    const jsonString = data.toString('utf8');
    return JSON.parse(jsonString);
    
  } catch (error) {
    throw new Error('Erreur lors du téléchargement depuis Mega: ' + error.message);
  }
}

// Fonction pour créer l'état d'authentification depuis SESSION_ID
async function createAuthStateFromSessionId(sessionId) {
  try {
    console.log('🔄 Chargement de la session depuis SESSION_ID...');
    
    // Créer le dossier session s'il n'existe pas
    const sessionDir = './session';
    if (!fs.existsSync(sessionDir)) {
      fs.mkdirSync(sessionDir, { recursive: true });
    }
    
    let credsData;
    
    // Vérifier si le SESSION_ID est un lien Mega complet ou juste l'ID
    if (sessionId.includes('mega.nz')) {
      // Télécharger depuis Mega avec megajs
      try {
        credsData = await downloadCredsFromMega(sessionId);
      } catch (megaError) {
        console.log('⚠️ Erreur Mega, tentative avec méthode alternative...');
        throw megaError;
      }
    } else {
      // Essayer de télécharger avec l'ID seulement
      try {
        credsData = await downloadCredsFromMega(sessionId);
      } catch (error) {
        console.log('⚠️ Impossible de télécharger, tentative de parsing direct...');
        throw error;
      }
    }
    
    // Sauvegarder les credentials
    const credsPath = path.join(sessionDir, 'creds.json');
    fs.writeFileSync(credsPath, JSON.stringify(credsData, null, 2));
    
    console.log('✅ Session chargée avec succès !');
    
    // Utiliser l'état d'authentification multi-fichiers
    return await useMultiFileAuthState(sessionDir);
    
  } catch (error) {
    console.error('❌ Erreur lors du chargement de la session:', error.message);
    throw error;
  }
}

// Fonction alternative pour parser directement le SESSION_ID (format base64)
function parseSessionId(sessionId) {
  try {
    // Format: NABGgJrT#p3sP2imdvXEgIeQkVUO9_7DojgmqPhZPBnax6kOhNeU
    // La partie avant # est l'ID, après # c'est la clé
    const [id, key] = sessionId.split('#');
    
    if (!id || !key) {
      throw new Error('Format SESSION_ID invalide. Format attendu: ID#KEY');
    }
    
    // Décoder les données base64
    const decodedKey = Buffer.from(key, 'base64');
    
    return {
      id,
      key: decodedKey
    };
  } catch (error) {
    throw new Error('Impossible de parser SESSION_ID: ' + error.message);
  }
}

// Fonction pour créer l'état d'authentification depuis SESSION_ID (méthode alternative)
async function createAuthFromSession(sessionId) {
  const sessionDir = './session';
  
  // Créer le dossier session s'il n'existe pas
  if (!fs.existsSync(sessionDir)) {
    fs.mkdirSync(sessionDir, { recursive: true });
  }
  
  try {
    // Méthode 1: Essayer de télécharger depuis Mega
    return await createAuthStateFromSessionId(sessionId);
  } catch (error) {
    console.log('⚠️ Impossible de charger depuis Mega, tentative de parsing direct...');
    
    try {
      // Méthode 2: Parser le SESSION_ID directement
      const parsedSession = parseSessionId(sessionId);
      
      // Créer un fichier creds.json basique avec les données parsées
      const basicCreds = {
        "noiseKey": {
          "private": parsedSession.key.slice(0, 32),
          "public": parsedSession.key.slice(32, 64)
        },
        "pairingEphemeralKeyPair": {
          "private": parsedSession.key.slice(64, 96),
          "public": parsedSession.key.slice(96, 128)
        },
        "signedIdentityKey": {
          "private": parsedSession.key.slice(128, 160),
          "public": parsedSession.key.slice(160, 192)
        },
        "signedPreKey": {
          "keyPair": {
            "private": parsedSession.key.slice(192, 224),
            "public": parsedSession.key.slice(224, 256)
          },
          "signature": parsedSession.key.slice(256, 320),
          "keyId": 1
        },
        "registrationId": parseInt(parsedSession.id, 36),
        "advSecretKey": parsedSession.key.slice(320, 352),
        "me": {
          "id": `${parsedSession.id}@s.whatsapp.net`,
          "name": "Bot"
        },
        "account": {
          "details": "",
          "accountSignatureKey": parsedSession.key.slice(352, 384),
          "accountSignature": parsedSession.key.slice(384, 448),
          "deviceSignature": parsedSession.key.slice(448, 512)
        }
      };
      
      // Sauvegarder les credentials
      const credsPath = path.join(sessionDir, 'creds.json');
      fs.writeFileSync(credsPath, JSON.stringify(basicCreds, null, 2));
      
      return await useMultiFileAuthState(sessionDir);
      
    } catch (parseError) {
      throw new Error('Impossible de parser SESSION_ID: ' + parseError.message);
    }
  }
}

async function startBot() {
  // Vérifier si SESSION_ID est défini dans config
  if (!config.SESSION_ID) {
    console.error('❌ SESSION_ID non défini dans config.js');
    console.log('📝 Veuillez ajouter votre SESSION_ID dans config.js:');
    console.log('   SESSION_ID: "votre_session_id_ici"');
    process.exit(1);
  }
  
  const { version } = await fetchLatestBaileysVersion();
  
  let state, saveCreds;
  
  try {
    // Créer l'état d'authentification depuis SESSION_ID
    const authState = await createAuthFromSession(config.SESSION_ID);
    state = authState.state;
    saveCreds = authState.saveCreds;
    
    console.log('✅ Authentification chargée depuis SESSION_ID');
  } catch (error) {
    console.error('❌ Erreur lors du chargement de la session:', error.message);
    console.log('💡 Vérifiez que votre SESSION_ID est valide');
    process.exit(1);
  }
  
  const sock = makeWASocket({
    version,
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'silent' }))
    },
    printQRInTerminal: false,
    browser: ['Mac OS', 'Safari', '20.0.04'],
    logger: pino({ level: 'silent' })
  });

  sock.ev.on('creds.update', saveCreds);

  sock.ev.on('connection.update', update => {
    const { connection, lastDisconnect } = update;
    if (connection === 'close') {
      const code = lastDisconnect?.error?.output?.statusCode;
      console.log('📵 Déconnecté, code', code);
      if (code !== DisconnectReason.loggedOut) {
        console.log('🔄 Reconnexion...');
        setTimeout(() => startBot(), 3000);
      } else {
        console.error('❌ Session expirée, veuillez générer une nouvelle SESSION_ID');
        process.exit(1);
      }
    } else if (connection === 'open') {
      console.log('✅ Connecté à WhatsApp');
      console.log('👤 Connecté en tant que:', sock.user.name || config.ownerName );
    }
  });

  // Charge les commandes automatiquement
  const commands = {};
  const commandsPath = path.join(__dirname, 'commands');
  fs.readdirSync(commandsPath)
    .filter(f => f.endsWith('.js'))
    .forEach(f => {
      const cmd = require(path.join(commandsPath, f));
      if (cmd.name) commands[cmd.name] = cmd;
    });

  // Import des fonctions antidelete
  let storeMessage, handleMessageRevocation;
  try {
    const antideleteModule = require('./commands/antidelete');
    storeMessage = antideleteModule.storeMessage;
    handleMessageRevocation = antideleteModule.handleMessageRevocation;
    console.log('📋 Module antidelete chargé');
  } catch (err) {
    console.log('⚠️ Module antidelete non trouvé ou erreur:', err.message);
    // Fonctions vides si le module n'existe pas
    storeMessage = async () => {};
    handleMessageRevocation = async () => {};
  }

  // Import des fonctions de mode
  let canExecuteCommand, loadModeConfig;
  try {
    const modeModule = require('./commands/mode');
    canExecuteCommand = modeModule.canExecuteCommand;
    loadModeConfig = modeModule.loadModeConfig;
    console.log('⚙️ Module mode chargé');
  } catch (err) {
    console.log('⚠️ Module mode non trouvé, mode public par défaut');
    // Fonction par défaut si le module n'existe pas
    canExecuteCommand = () => true;
    loadModeConfig = () => ({ mode: 'public' });
  }

  // Écoute des messages
  sock.ev.on('messages.upsert', async ({ messages }) => {
    for (const msg of messages) {
      if (!msg.message) continue;

      // ✅ ANTIDELETE: Stocker chaque message reçu
      try {
        await storeMessage(msg);
      } catch (err) {
        console.error('Erreur storeMessage:', err);
      }

      const jid = msg.key.remoteJid;
      const isGroup = jid.endsWith('@g.us');
      const content = msg.message.conversation
        || msg.message.extendedTextMessage?.text
        || '';

      const isCommand = content.startsWith(config.prefix);
      const sender = msg.key.participant || jid;

      console.log(`[${new Date().toISOString()}]`, isGroup ? '[GROUP]' : '[PRIVATE]', sender + ':', content);

      if (!isCommand) continue;

      const [cmdName, ...args] = content.slice(config.prefix.length).trim().split(/\s+/);
      const cmd = commands[cmdName.toLowerCase()];

      if (!cmd) {
        await sock.sendMessage(jid, { text: stylise(`❌ Commande inconnue. Tappez *${config.prefix}menu* !`) });
        continue;
      }

      try {
        // ✅ VÉRIFICATION DU MODE: Vérifier si l'utilisateur peut exécuter la commande
        if (!canExecuteCommand(msg)) {
          const modeConfig = loadModeConfig();
          await sock.sendMessage(jid, { 
            text: stylise(`🔒 *Bot en mode ${modeConfig.mode.toUpperCase()}*\n\n_Seul le propriétaire peut utiliser les commandes actuellement._`)
          });
          continue;
        }

        // Ignorer les groupes muted sauf menu ou unmute
        if (isGroup && db[jid]?.muted && !['menu', 'unmute'].includes(cmdName)) continue;

        await cmd.execute({
          sock,
          msg,
          args,
          db,
          saveDB,
          config,
          stylise,
          sendMenu,
          sendReply
        });

      } catch (err) {
        console.error('⚠️ Erreur dans la commande', cmdName, err);
        await sock.sendMessage(jid, { text: stylise('⚠️ Une erreur est survenue, désolé !') });
      }
    }
  });

  // ✅ ANTIDELETE: Écoute des suppressions de messages
  sock.ev.on('messages.update', async (updates) => {
    for (const update of updates) {
      try {
        // Vérifier si c'est une suppression de message
        if (update.update.messageStubType === 68 || // Message deleted
            update.update.messageStubType === 69 || // Message deleted for me
            (update.update.message && update.update.message.protocolMessage?.type === 0)) {
          
          await handleMessageRevocation(sock, update);
        }
      } catch (err) {
        console.error('Erreur handleMessageRevocation:', err);
      }
    }
  });

  // ✅ ANTIDELETE: Alternative - Écoute des messages de protocole
  sock.ev.on('messages.upsert', async ({ messages }) => {
    for (const msg of messages) {
      try {
        // Détecter les messages de révocation (suppression)
        if (msg.message?.protocolMessage?.type === 0) { // REVOKE
          await handleMessageRevocation(sock, msg);
        }
      } catch (err) {
        console.error('Erreur protocol message:', err);
      }
    }
  });

  return sock;
}

// Démarrer le bot
startBot().catch(console.error);