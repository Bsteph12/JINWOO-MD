// commands/menu.js

module.exports = {
  name: 'menu',
  description: 'Affiche le menu principal du bot avec image seulement',
  
  async execute({ sock, msg, config, stylise }) {
    // Vérifications de sécurité
    if (!sock || !msg || !msg.key || !msg.key.remoteJid) {
      console.error('❌ Paramètres manquants dans la commande menu');
      return;
    }

    const jid = msg.key.remoteJid;
    const prefix = config.prefix;
    
    const menuText = [
      '╭━━[ FINN_V1 ]━━╮',
      '│',
      `│ User       : ${config.ownerName} `, 
      `│ Bot Name   : ${config.botName} `, 
      `│ Prefix     : ${prefix} `, 
      `│ Mode       : ${config.mode} `, 
      '│ Platform   : linux', 
      '│ Version    : 1', 
      '│ Library    : Baileys', 
      '│ Commands   : 10', 
      '╰━━━━━━━━━━━━━━━╯', 
      '', 
      '', 
      '*██▒­░⡷⠂𝙲𝙾𝙼𝙼𝙰𝙽𝙳𝚂⠐⢾░▒██ *',
      '', 
      '', 
      '┌❏ *_OWNER_MENU_* ',
      '│', 
      `│➼ ${prefix}ping`,
      `│➼ ${prefix}alive`,
      `│➼ ${prefix}repo`,
      `│➼ ${prefix}owner`,
      `│➼ ${prefix}mode`,
      '│',
      '└ ❏', 
      '', 
      '┌❏ *_GROUPS_COMMANDS_*',
      '│', 
      `│➼ ${prefix}mute`,
      `│➼ ${prefix}unmute`,
      `│➼ ${prefix}tagall`,
      `│➼ ${prefix}hidetag`,
      '│',
      '└ ❏', 
      '', 
      '┌❏ *_TOOLS_COMMANDS_*',
      '│', 
      `│➼ ${prefix}welcome`,
      `│➼ ${prefix}goodbye`,
      `│➼ ${prefix}viewonce`,
      `│➼ ${prefix}antidelete`,
      '│',
      '└ ❏',
      '',
      ' *© Finn v1 by dsdev*'
    ].join('\n');

    // Pas besoin de contextInfo pour une image simple

    try {
      // Envoyer l'image avec le texte en caption (sans lien)
      await sock.sendMessage(jid, {
        image: { url: 'https://i.postimg.cc/sg8Dfk36/60b2e6e4b6e2749d6f329a3468d22046.jpg' },
        caption: menuText
      });
      
      console.log('✅ Menu envoyé avec image simple');
      
    } catch (err) {
      console.error('❌ Erreur lors de l\'envoi du menu avec image:', err);
      
      // Fallback: Menu texte simple seulement
      try {
        await sock.sendMessage(jid, { 
          text: menuText 
        });
        console.log('⚠️ Menu envoyé en fallback texte simple');
      } catch (finalErr) {
        console.error('❌ Erreur dans le fallback final:', finalErr);
      }
    }
  }
};