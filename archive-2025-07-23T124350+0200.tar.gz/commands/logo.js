const axios = require('axios');

module.exports = {
  name: 'logo',
  description: 'Génère différents types de logos avec du texte',
  
  async execute({ sock, msg, config, stylise }) {
    if (!sock || !msg || !msg.key || !msg.key.remoteJid) {
      console.error('❌ Paramètres manquants dans la commande logo');
      return;
    }

    const jid = msg.key.remoteJid;
    
    try {
      const text = msg.message?.conversation || 
                   msg.message?.extendedTextMessage?.text || '';
      const args = text.split(' ').slice(1);
      const logoText = args.join(' ').trim();
      
      if (!logoText) {
        const helpText = [
          '╔═══════◇◆◇═══════╗',
          '⌜ 🎨 𝗟𝗢𝗚𝗢 𝗚𝗘𝗡𝗘𝗥𝗔𝗧𝗢𝗥 ⌟',
          '╚═══════◇◆◇═══════╝',
          '',
          '❌ *Texte manquant !*',
          '',
          `📖 *Usage:* ${config.prefix}logo [texte]`,
          `📝 *Exemple:* ${config.prefix}logo Mon Team`,
          '',
          '🎯 *Logos disponibles:*',
          '• Neon - Style néon coloré',
          '• Gaming - Logo gaming/équipe',
          '• 3D - Effet 3D moderne',
          '• Metal - Style métallique',
          '• Glitch - Effet glitch numérique',
          '',
          `💡 *Tip:* Utilisez ${config.prefix}neon, ${config.prefix}gaming, etc.`,
          '',
          '💻 *by ste_phane_*'
        ].join('\n');

        return await sock.sendMessage(jid, { 
          text: stylise ? stylise(helpText) : helpText
        });
      }

      // Logo neon par défaut
      await generateLogo(sock, jid, logoText, 'neon', msg, stylise);

    } catch (error) {
      console.error('❌ Erreur dans la commande logo:', error);
      await sendErrorMessage(sock, jid, error.message, stylise);
    }
  }
};

// Fonction générique pour générer les logos
async function generateLogo(sock, jid, text, type, quotedMsg, stylise) {
  try {
    // URLs pour différents types de logos basés sur l'API
    const logoTypes = {
      'neon': 'https://en.ephoto360.com/create-colorful-neon-light-text-effects-online-797.html',
      'gaming': 'https://en.ephoto360.com/free-gaming-logo-maker-for-fps-game-team-546.html',
      '3d': 'https://en.ephoto360.com/create-glossy-silver-3d-text-effect-online-802.html',
      'metal': 'https://en.ephoto360.com/metal-logo-online-108.html',
      'glitch': 'https://en.ephoto360.com/create-digital-glitch-text-effects-online-767.html',
      'marvel': 'https://en.ephoto360.com/create-marvel-style-logo-419.html',
      'avengers': 'https://en.ephoto360.com/create-logo-3d-style-avengers-online-427.html',
      'blackpink': 'https://en.ephoto360.com/create-blackpink-logo-online-free-607.html',
      'deadpool': 'https://en.ephoto360.com/create-text-effects-in-the-style-of-the-deadpool-logo-818.html',
      'naruto': 'https://en.ephoto360.com/naruto-shippuden-logo-style-text-effect-online-808.html'
    };

    const logoUrl = logoTypes[type] || logoTypes['neon'];
    const logoName = type.charAt(0).toUpperCase() + type.slice(1);

    // Message de génération
    const loadingText = [
      '╔═══════◇◆◇═══════╗',
      `⌜ 🎨 𝗚𝗘𝗡𝗘𝗥𝗔𝗧𝗜𝗢𝗡 ${logoName.toUpperCase()} ⌟`,
      '╚═══════◇◆◇═══════╝',
      '',
      '🔄 *Génération en cours...*',
      `🎯 *Style:* ${logoName}`,
      `📝 *Texte:* ${text}`,
      '',
      '⏳ _Veuillez patienter..._'
    ].join('\n');

    await sock.sendMessage(jid, {
      text: stylise ? stylise(loadingText) : loadingText
    });

    console.log(`🎨 Génération logo ${type} pour: "${text}"`);

    // API call pour générer le logo
    const apiUrl = `https://apis-keith.vercel.app/ephoto360?url=${encodeURIComponent(logoUrl)}&text=${encodeURIComponent(text)}`;
    
    const response = await axios.get(apiUrl, {
      timeout: 30000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    });

    if (response.data && response.data.status && response.data.result) {
      const imageUrl = response.data.result;
      
      // Message de succès
      const successText = [
        '╔═══════◇◆◇═══════╗',
        `⌜ ✅ ${logoName.toUpperCase()} 𝗥𝗘𝗔𝗗𝗬 ⌟`,
        '╚═══════◇◆◇═══════╝',
        '',
        '🎉 *Logo généré avec succès !*',
        `🎨 *Style:* ${logoName}`,
        `📝 *Texte:* ${text}`,
        '',
        '📤 _Envoi en cours..._'
      ].join('\n');

      await sock.sendMessage(jid, {
        text: stylise ? stylise(successText) : successText
      });

      // Envoi de l'image
      await sock.sendMessage(jid, {
        image: { url: imageUrl },
        caption: `🎨 **${logoName} Logo**\n📝 *Texte:* ${text}\n\n💻 *by ste_phane_*`
      }, { quoted: quotedMsg });

      console.log(`✅ Logo ${type} envoyé avec succès`);

    } else {
      throw new Error('Réponse API invalide');
    }

  } catch (error) {
    console.error(`❌ Erreur génération logo ${type}:`, error);
    throw error;
  }
}

// Fonction pour envoyer les messages d'erreur
async function sendErrorMessage(sock, jid, errorMsg, stylise) {
  const errorText = [
    '╔═══════◇◆◇═══════╗',
    '⌜ ❌ 𝗘𝗥𝗥𝗘𝗨𝗥 ⌟',
    '╚═══════◇◆◇═══════╝',
    '',
    '🚫 *Échec de la génération*',
    '',
    '🔧 *Causes possibles:*',
    '• Problème de connexion',
    '• API temporairement indisponible',
    '• Texte trop long ou caractères spéciaux',
    '',
    '💡 *Solutions:*',
    '• Réessayez dans quelques minutes',
    '• Utilisez un texte plus court',
    '• Évitez les caractères spéciaux',
    '',
    '💻 *by ste_phane_*'
  ].join('\n');

  try {
    await sock.sendMessage(jid, { 
      text: stylise ? stylise(errorText) : errorText
    });
  } catch (fallbackErr) {
    console.error('❌ Erreur dans le fallback:', fallbackErr);
    try {
      await sock.sendMessage(jid, { 
        text: "❌ Échec de la génération du logo. Réessayez plus tard."
      });
    } catch (finalErr) {
      console.error('❌ Erreur finale:', finalErr);
    }
  }
}

/*
 * Powered by Jł₦₩ØØ Bot
 * Logo Generator Command
 * Created by ste_phane_
 */