module.exports = {
  name: 'neon',
  description: 'Génère un logo avec effet néon coloré',
  
  async execute({ sock, msg, config, stylise }) {
    if (!sock || !msg || !msg.key || !msg.key.remoteJid) {
      console.error('❌ Paramètres manquants dans la commande neon');
      return;
    }

    const jid = msg.key.remoteJid;
    
    try {
      const text = msg.message?.conversation || 
                   msg.message?.extendedTextMessage?.text || '';
      const logoText = text.split(' ').slice(1).join(' ').trim();
      
      if (!logoText) {
        const helpText = [
          '╔═══════◇◆◇═══════╗',
          '⌜ 🌈 𝗡𝗘𝗢𝗡 𝗟𝗢𝗚𝗢 ⌟',
          '╚═══════◇◆◇═══════╝',
          '',
          '❌ *Texte manquant !*',
          '',
          `📖 *Usage:* ${config.prefix}neon [texte]`,
          `📝 *Exemple:* ${config.prefix}neon Gaming Team`,
          '',
          '🎨 *Effet:* Néon coloré brillant',
          '',
          '💻 *by ste_phane_*'
        ].join('\n');

        return await sock.sendMessage(jid, { 
          text: stylise ? stylise(helpText) : helpText
        });
      }

      const { generateLogo } = require('./logo');
      await generateLogo(sock, jid, logoText, 'neon', msg, stylise);

    } catch (error) {
      console.error('❌ Erreur dans la commande neon:', error);
      const { sendErrorMessage } = require('./logo');
      await sendErrorMessage(sock, jid, error.message, stylise);
    }
  }
};

/*
 * Powered by Jł₦₩ØØ Bot
 * Neon Logo Command
 * Created by ste_phane_
 */
