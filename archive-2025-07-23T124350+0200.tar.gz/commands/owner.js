// commands/owner.js

module.exports = {

  name: 'owner',

  description: 'Affiche les informations de contact du propriétaire du bot',

  

  async execute({ sock, msg, config, stylise }) {

    // Vérifications de sécurité

    if (!sock || !msg || !msg.key || !msg.key.remoteJid) {

      console.error('❌ Paramètres manquants dans la commande owner');

      return;

    }

    const jid = msg.key.remoteJid;

    

    // Vérification que les infos owner existent dans config

    if (!config.botOwner || !config.ownerNumber) {

      console.error('❌ Informations owner manquantes dans config');

      const errorText = [

        '╔═══════◇◆◇═══════╗',

        '⌜ ❌ 𝗖𝗢𝗡𝗙𝗜𝗚 𝗘𝗥𝗥𝗢𝗥 ⌟',

        '╚═══════◇◆◇═══════╝',

        '',

        '🚫 *Configuration manquante !*',

        '',

        '🔧 *Vérifiez votre fichier config:*',

        '• botOwner: "Votre nom"',

        '• ownerNumber: "Votre numéro"',

        '',

        '💻 *by ste_phane_*'

      ].join('\n');

      return await sock.sendMessage(jid, { 

        text: stylise ? stylise(errorText) : errorText

      });

    }

    // Nettoyage du numéro (enlever les espaces, tirets, etc.)

    let cleanNumber = config.ownerNumber.toString().replace(/[\s\-\(\)]/g, '');

    

    // Ajouter le préfixe international si manquant

    if (!cleanNumber.startsWith('+') && !cleanNumber.startsWith('237')) {

      cleanNumber = '237' + cleanNumber; // Préfixe Cameroun par défaut

    }

    if (cleanNumber.startsWith('+')) {

      cleanNumber = cleanNumber.substring(1);

    }

    console.log(`📞 Préparation du contact owner: ${config.botOwner} (${cleanNumber})`);

    

    // Création de la vCard

    const vcard = `BEGIN:VCARD

VERSION:3.0

FN:${config.botOwner}

TEL;waid=${cleanNumber}:+${cleanNumber}

END:VCARD`;

    // Configuration du contextInfo avec image et lien (optionnel)

    const contextInfo = {

      mentionedJid: [],

      forwardingScore: 99,

      isForwarded: true,

      forwardedNewsletterMessageInfo: {

        newsletterJid: '120363419336864081@newsletter',

        serverMessageId: 21,

        newsletterName: 'Jł₦₩ØØ'

      },

      externalAdReply: {

        title: "👤 Contact Owner",

        body: `${config.botOwner} - Propriétaire du bot`,

        thumbnailUrl: 'https://i.postimg.cc/Hn9PbMg1/2c6ca349055f63a31a122697503257dd.jpg',

        sourceUrl: 'https://youtube.com/@votre-chaine',

        mediaType: 1,

        renderLargerThumbnail: false,

        showAdAttribution: true,

        containsAutoReply: true,

        jpegThumbnail: null

      }

    };

    try {

      // Envoi du contact avec contextInfo enrichi

      await sock.sendMessage(jid, {

        contacts: { 

          displayName: config.botOwner, 

          contacts: [{ vcard }] 

        },

        contextInfo: contextInfo

      });

      

      console.log('✅ Contact owner envoyé avec succès avec contextInfo');

      

    } catch (err) {

      console.error('❌ Erreur lors de l\'envoi du contact enrichi:', err);

      

      // Fallback 1: Contact sans contextInfo

      try {

        await sock.sendMessage(jid, {

          contacts: { 

            displayName: config.botOwner, 

            contacts: [{ vcard }] 

          }

        });

        console.log('⚠️ Contact owner envoyé en fallback (sans contextInfo)');

      } catch (fallbackErr) {

        console.error('❌ Erreur dans le fallback contact:', fallbackErr);

        

        // Fallback 2: Message texte avec les informations

        try {

          const fallbackText = [

            '╔═══════◇◆◇═══════╗',

            '⌜ 👤 𝗢𝗪𝗡𝗘𝗥 𝗖𝗢𝗡𝗧𝗔𝗖𝗧 ⌟',

            '╚═══════◇◆◇═══════╝',

            '',

            `👤 *Nom:* ${config.botOwner}`,

            `📱 *Numéro:* +${cleanNumber}`,

            `💬 *WhatsApp:* wa.me/${cleanNumber}`,

            '',

            '📞 *Cliquez sur le lien pour contacter*',

            '',

            '💻 *by ste_phane_*'

          ].join('\n');

          await sock.sendMessage(jid, { 

            text: stylise ? stylise(fallbackText) : fallbackText,

            contextInfo: {

              externalAdReply: {

                title: "👤 Contact Owner",

                body: "Cliquez pour contacter",

                sourceUrl: `https://wa.me/${cleanNumber}`,

                mediaType: 1

              }

            }

          });

          console.log('⚠️ Informations owner envoyées en fallback texte');

        } catch (finalErr) {

          console.error('❌ Erreur dans le fallback final:', finalErr);

          

          // Dernier fallback ultra simple

          try {

            await sock.sendMessage(jid, { 

              text: `👤 **Owner:** ${config.botOwner}\n📱 **Contact:** +${cleanNumber}\n💬 **WhatsApp:** wa.me/${cleanNumber}`

            });

          } catch (ultraFinalErr) {

            console.error('❌ Erreur ultra finale:', ultraFinalErr);

          }

        }

      }

    }

  }

};