// commands/play.js
// Version améliorée avec la bonne structure API

const axios = require('axios');

module.exports = {
  name: 'play',
  description: 'Télécharge et envoie une chanson depuis YouTube',
  
  async execute({ sock, msg, config, stylise }) {
    // Vérifications de sécurité
    if (!sock || !msg || !msg.key || !msg.key.remoteJid) {
      console.error('❌ Paramètres manquants dans la commande play');
      return;
    }

    const jid = msg.key.remoteJid;
    
    try {
      // Extraction du texte de recherche
      const text = msg.message?.conversation || 
                   msg.message?.extendedTextMessage?.text || '';
      const searchQuery = text.split(' ').slice(1).join(' ').trim();
      
      if (!searchQuery) {
        const helpText = [
          '╔═══════◇◆◇═══════╗',
          '⌜ 🎵 𝗣𝗟𝗔𝗬 𝗖𝗢𝗠𝗠𝗔𝗡𝗗 ⌟',
          '╚═══════◇◆◇═══════╝',
          '',
          '❌ *Titre manquant !*',
          '',
          `📖 *Usage:* ${config.prefix}play [titre]`,
          `📝 *Exemple:* ${config.prefix}play Imagine Dragons`,
          '',
          '💻 *by ste_phane_*'
        ].join('\n');

        return await sock.sendMessage(jid, { 
          text: stylise ? stylise(helpText) : helpText
        });
      }

      // Message de recherche
      const searchText = [
        '╔═══════◇◆◇═══════╗',
        '⌜ 🔍 𝗥𝗘𝗖𝗛𝗘𝗥𝗖𝗛𝗘 ⌟',
        '╚═══════◇◆◇═══════╝',
        '',
        '🎵 *Recherche en cours...*',
        `🎯 *Titre:* ${searchQuery}`,
        '',
        '⏳ _Veuillez patienter..._'
      ].join('\n');

      await sock.sendMessage(jid, {
        text: stylise ? stylise(searchText) : searchText
      });

      console.log(`🔍 Recherche pour: "${searchQuery}"`);

      // Variables pour stocker les infos
      let audioData;

      try {
        // Recherche et téléchargement avec l'API Keith améliorée
        const apiUrl = `https://apis-keith.vercel.app/download/dlmp3?url=ytsearch:${encodeURIComponent(searchQuery)}`;
        
        console.log(`🌐 Appel API: ${apiUrl}`);
        
        const response = await axios.get(apiUrl, {
          timeout: 30000,
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
          }
        });

        console.log('📡 Réponse reçue:', response.data);

        // Vérification de la structure de réponse
        if (response.data && 
            response.data.status === true && 
            response.data.result && 
            response.data.result.success === true && 
            response.data.result.data) {
          
          audioData = response.data.result.data;
          console.log('✅ Données audio extraites:', audioData);
        } else {
          throw new Error('Structure de réponse invalide');
        }

      } catch (apiErr) {
        console.error('❌ Erreur API principale:', apiErr.message);
        
        // Fallback avec recherche séparée
        try {
          console.log('🔄 Tentative avec recherche séparée...');
          
          // D'abord rechercher la vidéo
          const searchResponse = await axios.get(`https://apis-keith.vercel.app/search/ytsearch?q=${encodeURIComponent(searchQuery)}`, {
            timeout: 15000
          });

          if (searchResponse.data && 
              searchResponse.data.results && 
              searchResponse.data.results.length > 0) {
            
            const video = searchResponse.data.results[0];
            const videoUrl = video.url;
            
            console.log(`🎥 Vidéo trouvée: ${video.title}`);
            
            // Ensuite télécharger avec l'URL de la vidéo
            const downloadResponse = await axios.get(`https://apis-keith.vercel.app/download/dlmp3?url=${videoUrl}`, {
              timeout: 30000
            });

            if (downloadResponse.data && 
                downloadResponse.data.status === true && 
                downloadResponse.data.result && 
                downloadResponse.data.result.success === true && 
                downloadResponse.data.result.data) {
              
              audioData = downloadResponse.data.result.data;
            } else {
              throw new Error('Échec du téléchargement');
            }
          } else {
            throw new Error('Aucun résultat trouvé');
          }
        } catch (fallbackErr) {
          console.error('❌ Erreur fallback:', fallbackErr.message);
          throw new Error('Toutes les tentatives ont échoué');
        }
      }

      if (!audioData || !audioData.downloadUrl) {
        throw new Error('URL de téléchargement introuvable');
      }

      // Formatage des données
      const title = audioData.title || 'Titre inconnu';
      const duration = audioData.duration ? `${Math.floor(audioData.duration / 60)}:${String(audioData.duration % 60).padStart(2, '0')}` : 'Durée inconnue';
      const quality = audioData.quality ? `${audioData.quality}kbps` : 'Qualité inconnue';
      const thumbnail = audioData.thumbnail || 'https://i.postimg.cc/Hn9PbMg1/2c6ca349055f63a31a122697503257dd.jpg';
      const downloadUrl = audioData.downloadUrl;

      // Message de téléchargement
      const downloadText = [
        '╔═══════◇◆◇═══════╗',
        '⌜ 📥 𝗧𝗘𝗟𝗘𝗖𝗛𝗔𝗥𝗚𝗘𝗠𝗘𝗡𝗧 ⌟',
        '╚═══════◇◆◇═══════╝',
        '',
        '🎵 *Téléchargement en cours...*',
        `📀 *Titre:* ${title}`,
        `⏱️ *Durée:* ${duration}`,
        `🎧 *Qualité:* ${quality}`,
        '',
        '⬇️ _Envoi du fichier audio..._'
      ].join('\n');

      await sock.sendMessage(jid, {
        text: stylise ? stylise(downloadText) : downloadText
      });

      // Configuration du contextInfo pour l'audio
      const contextInfo = {
        mentionedJid: [],
        forwardingScore: 99,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
          newsletterJid: '120363419336864081@newsletter',
          serverMessageId: 22,
          newsletterName: 'Jł₦₩ØØ Music'
        },
        externalAdReply: {
          title: title,
          body: `${duration} • ${quality}`,
          thumbnailUrl: thumbnail,
          sourceUrl: 'https://youtube.com/@votre-chaine',
          mediaType: 1,
          renderLargerThumbnail: true,
          showAdAttribution: false,
          containsAutoReply: true
        }
      };

      // Envoi de l'audio avec contextInfo
      await sock.sendMessage(jid, {
        audio: { url: downloadUrl },
        mimetype: "audio/mpeg",
        fileName: `${title.replace(/[^\w\s-]/gi, '').trim()}.mp3`,
        contextInfo: contextInfo
      }, { quoted: msg });

      console.log('✅ Audio envoyé avec succès');

      // Message de confirmation
      const successText = [
        '╔═══════◇◆◇═══════╗',
        '⌜ ✅ 𝗦𝗨𝗖𝗖𝗘𝗦 ⌟',
        '╚═══════◇◆◇═══════╝',
        '',
        '🎉 *Téléchargement terminé !*',
        `🎵 **${title}**`,
        `⏱️ ${duration} | 🎧 ${quality}`,
        '',
        '💻 *by ste_phane_*'
      ].join('\n');

      setTimeout(async () => {
        try {
          await sock.sendMessage(jid, {
            text: stylise ? stylise(successText) : successText
          });
        } catch (err) {
          console.log('Info: Message de confirmation ignoré');
        }
      }, 2000);

    } catch (error) {
      console.error('❌ Erreur dans la commande play:', error);
      
      // Message d'erreur stylisé
      const errorText = [
        '╔═══════◇◆◇═══════╗',
        '⌜ ❌ 𝗘𝗥𝗥𝗘𝗨𝗥 ⌟',
        '╚═══════◇◆◇═══════╝',
        '',
        '🚫 *Échec du téléchargement*',
        '',
        '🔧 *Causes possibles:*',
        '• Aucun résultat trouvé',
        '• Problème de connexion',
        '• API temporairement indisponible',
        '• Vidéo non disponible',
        '',
        '💡 *Solutions:*',
        '• Vérifiez l\'orthographe du titre',
        '• Essayez un autre titre',
        '• Réessayez dans quelques minutes',
        '• Utilisez des mots-clés plus précis',
        '',
        `📝 *Recherche effectuée:* ${text.split(' ').slice(1).join(' ').trim()}`,
        '',
        '💻 *by ste_phane_*'
      ].join('\n');

      // Envoi du message d'erreur
      try {
        await sock.sendMessage(jid, { 
          text: stylise ? stylise(errorText) : errorText
        });
      } catch (fallbackErr) {
        console.error('❌ Erreur dans le fallback:', fallbackErr);
        try {
          await sock.sendMessage(jid, { 
            text: "❌ Échec du téléchargement. Vérifiez le titre et réessayez."
          });
        } catch (finalErr) {
          console.error('❌ Erreur finale:', finalErr);
        }
      }
    }
  }
};

/*
 * Powered by Jł₦₩ØØ Bot
 * Improved Play Command with Keith API
 * Enhanced by ste_phane_
 * 
 * Fonctionnalités:
 * - Utilise la structure de réponse correcte de l'API Keith
 * - Gestion d'erreurs robuste avec fallback
 * - Messages stylisés avec informations détaillées
 * - Support des thumbnails et métadonnées
 * - Formatage automatique de la durée
 * - Nettoyage des noms de fichiers
 * - Timeout adaptatifs pour les requêtes
 */