const fs = require('fs');
const path = require('path');

const MODE_CONFIG_PATH = path.join(__dirname, '../data/mode.json');

// Ensure data dir exists
const dataDir = path.dirname(MODE_CONFIG_PATH);
if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
}

// Load mode config
function loadModeConfig() {
    try {
        if (!fs.existsSync(MODE_CONFIG_PATH)) {
            // Default to public mode
            const defaultConfig = { mode: 'public' };
            saveModeConfig(defaultConfig);
            return defaultConfig;
        }
        return JSON.parse(fs.readFileSync(MODE_CONFIG_PATH, 'utf8'));
    } catch (err) {
        console.error('Error loading mode config:', err);
        return { mode: 'public' };
    }
}

// Save mode config
function saveModeConfig(config) {
    try {
        fs.writeFileSync(MODE_CONFIG_PATH, JSON.stringify(config, null, 2));
    } catch (err) {
        console.error('Error saving mode config:', err);
    }
}

// Check if user is owner
function isOwner(msg) {
    // Le bot owner est celui qui a la clé fromMe = true
    // ou vous pouvez définir des numéros spécifiques
    return msg.key.fromMe;
}

// Check if user can execute commands based on current mode
function canExecuteCommand(msg) {
    const config = loadModeConfig();
    
    if (config.mode === 'public') {
        return true; // Tout le monde peut utiliser les commandes
    } else if (config.mode === 'private') {
        return isOwner(msg); // Seul le propriétaire peut utiliser
    }
    
    return false;
}

module.exports = {
    name: 'mode',
    description: 'Gère le mode du bot (private/public)',
    async execute({ sock, msg, sendReply, args }) {
        // Seul le propriétaire peut changer le mode
        if (!isOwner(msg)) {
            return sendReply(sock, msg, '*❌ Seul le propriétaire du bot peut utiliser cette commande.*');
        }

        const config = loadModeConfig();
        const newMode = args[0]?.toLowerCase();

        // Si pas d'argument, afficher le mode actuel
        if (!newMode) {
            const statusEmoji = config.mode === 'private' ? '🔒' : '🌐';
            const statusText = config.mode === 'private' ? 'Privé' : 'Public';
            
            return sendReply(sock, msg,
                `*❏CONFIGURATION MODE BOT*\n\n` +
                `Mode actuel: ${statusEmoji} *${statusText}*\n\n` +
                `*│➼ Mode Privé:* Seul le propriétaire peut utiliser les commandes\n` +
                `*│➼ Mode Public:* Tout le monde peut utiliser les commandes\n\n` +
                `*Utilisation:*\n` +
                `*.mode private* - Passer en mode privé\n` +
                `*.mode public* - Passer en mode public`
            );
        }

        // Valider et changer le mode
        if (newMode === 'private') {
            config.mode = 'private';
            saveModeConfig(config);
            return sendReply(sock, msg, '*│➼PRIVATE ENABLED*');
            
        } else if (newMode === 'public') {
            config.mode = 'public';
            saveModeConfig(config);
            return sendReply(sock, msg, '*│➼PUBLIC ENABLED*');
            
        } else {
            return sendReply(sock, msg, '*❌ Mode invalide. Utilisez:*\n*.mode private* ou *.mode public*');
        }
    },
    
    // Export helper functions for use in main bot
    canExecuteCommand,
    loadModeConfig,
    isOwner
};